//#-hidden-code
//
//  Contents.swift
//
import Foundation
start()
DispatchQueue.global(qos: .background).async {
//#-end-hidden-code
/*:#localized(key: "ExplorerNarative")
To use the Explorer playground book make sure your micro:bit is flashed with the **Explorer Program**. *For more details see:* [Flash the micro:bit with the explorer program](https://phwallen.github.io/microbit-explorer/#flash-the-microbit-with-the-explorer-program).
     
Connect your micro:bit to a suitable power supply and check that **R** is displayed on the LED matrix.
     
[Overview and Features of Micro:bit Explorer](https://phwallen.github.io/microbit-explorer/)
 
 */
    //#-editable-code
    
    //#-end-editable-code

//#-hidden-code
   finish()
}
//#-end-hidden-code
