//#-hidden-code
//
//  Contents.swift
//
import Foundation
start()
DispatchQueue.global(qos: .background).async {
//#-end-hidden-code
/*:#localized(key: "ExplorerNarative")
To use the Explorer playground book make sure your micro:bit is flashed with the **Explorer Program**. *For more details see:* [Flash the micro:bit with the explorer program](https://phwallen.github.io/microbit-explorer/#flash-the-microbit-with-the-explorer-program)
 Connect your micro:bit to a suitable power supply and check that **R** is displayed on the LED matrix.
 
 */
    //#-editable-code
clear()
let source = """
mov r1,#97 @ dividend
mov r2,#42 @ divisor
mov r0,#0  @ clear quotient
mov r3,#1  @ intialise pointer
start:
lsl r2,r2,#1
lsl r3,r3,#1
cmp r2,r1
bls start
next:
cmp r1,r2
bcc skip
sub r1,r1,r2 @ execute if carry set
add r0,r0,r3 @ execute if carry set
skip:
asr r3,r3,#1
bcs carry_set
asr r2,r2,#1 @ execute if carry clear
carry_set:
bcc next
mov r7,#45 @ indicate end
"""
let machine_code = assemble(source)
program(machine_code)
    //#-end-editable-code

//#-hidden-code
   finish()
}
//#-end-hidden-code
